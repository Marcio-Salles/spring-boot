package com.example.exerciciosb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExercicioSbApplicationTests {

	@Test
	void contextLoads() {
	}

}
