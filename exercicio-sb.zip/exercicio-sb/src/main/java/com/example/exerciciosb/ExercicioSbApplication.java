package com.example.exerciciosb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExercicioSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExercicioSbApplication.class, args);
	}

}
